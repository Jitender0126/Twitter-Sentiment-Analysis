
from setuptools import setup

setup(
  name="sentiment_analysis_classifier",
  version="0.1",
  include_package_data=True,
  scripts=["preprocess.py", "model_prediction.py"]
)
